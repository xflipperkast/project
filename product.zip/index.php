<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Versiebeheer 2.T1 LO1E</title>
    <link href="css/home.css" rel="stylesheet" type="text/css">
</head>
<body>
  <h1>inloggen</h1>
  <nav>
    <img id="logo" src="img/logo.png" alt="logo">
    <article>
      <a href="#" class="nav">Home</a>
      <a href="#" class="nav">Producten</a>
      <a href="#" class="nav">Evenementen</a>
      <a href="#" class="nav">Contact</a>
</article>
</nav>
</body>
</html>