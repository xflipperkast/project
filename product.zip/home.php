<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="css/homepage.css" rel="stylesheet" type="text/css">
<nav class="navbar navbar-expand-sm navbar-dark">
    <img src="img/logo.png" width="200" alt=""> 
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation"> 
        <span class="navbar-toggler-icon"></span> 
    </button>
    <div class="end">
        <div class="collapse navbar-collapse" id="navbarColor02">
            <ul class="navbar-nav">
            <li class="nav-item active"> <a class="nav-link mt-2" href="home.php" data-abc="true" id="clicked">Home<span class="sr-only">(current)</span></a> </li>
                <li class="nav-item"> <a class="nav-link" href="product.php" data-abc="true">producten</a> </li>
                <li class="nav-item"> <a class="nav-link" href="reacties.php" data-abc="true">Evenementen</a> </li>
                <li class="nav-item"> <a class="nav-link" href="artiesten.php" data-abc="true">Artiesten</a> </li>
                <li class="nav-item"> <a class="nav-link" href="contact.php" data-abc="true">Contact</a> </li>
				<li class="nav-item"> <a class="nav-link" href="Login.php" data-abc="true">inloggen</a> </li>
            </ul>        
        </div>
    </div>    
</nav>
<!-- Main Body -->
<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-md-4">
            <img class="ani" src="img/blikjes.png">
            </div>
            <div class="col-lg-5 col-md-7 col-sm-4 offset-md-1 col-14 mt-4">
            <h1>Welkom</h1>
       <p class="texts">Green dragon is de nieuwste en sterkste energie drink van deze tijd met 
        ons nieuwe recept is onze energie niet alleen powerfull maar ook laag in 
        calorieën tijdens festivals of projecten big or small Green dragon can give 
        it all.</p>
        <img class="imgtextback" src="img/draakje.png" width="50%">
            </div>
        </div>
    </div>
</section>